将源码目录aikev3.5_demo下的内容完整上传服务器，
假设你的服务器域名是aaa.com，那么浏览器输入http://www.aaa.com即可打开首页，
输入http://www.aaa.com/admin即可进入后台
后台缺省用户名和密码分别是admin/admin
后台权限已经开放，可以随意修改设置。不需要的设置栏目可以留空。
本源码来自网络搜集并修改，只供学习交流使用。
by fy
2018
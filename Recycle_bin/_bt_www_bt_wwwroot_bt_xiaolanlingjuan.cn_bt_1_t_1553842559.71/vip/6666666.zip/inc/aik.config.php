<?php
 $aik =  array (
  'sitename' => '爱客影院',
  'pcdomain' => 'http://vip.5aiym.top/',
  'title' => '爱客影院-免VIP抢先观看最新好看的电影和电视剧',
  'keywords' => '小生活网，VIP影视,电视直播网站,零八影院快播,高清云影视,云点播,免费看视频,湖南卫视直播,80电影网,最新电影天堂，免费在线观看，2018影视解析接口',
  'description' => '小生活网VIP影视，热剧快播,最好看的剧情片尽在小生活网VIP视频,高清云影视免费为大家提供最新最全的免费电影，电视剧，综艺，动漫无广告，在线云点播，电视直播',
  'homelink' => '<a href="http://vip.5aiym.top/" target="_blank"><font color="red">【aike】</font></a>',
  'icp' => 'ICP备案号',
  'foot' => '本站提供的最新电影和电视剧资源均系收集于各大视频网站,本站只提供web页面服务,并不提供影片资源存储,也不参与录制、上传</br>若本站收录的节目无意侵犯了贵司版权，请给网页底部邮箱地址来信,我们会及时处理和回复,谢谢。',
  'tongji' => '',
  'changyan' => '',
  'youlian' => '<a target="blank" class="gobtn" href="https://ym.5aiym.top">羊毛小生活网</a>
<a target="blank" class="gobtn" href="http://vip.5aiym.top">aike影视</a>',
  'shouquan' => '',
  'zhanwai' => 'http://iic.nasaosa.com/',
  'zhanwai1' => 'http://okzyzy.cc/',
  'cilis' => 'http://www.btyes.net/',
  'jiekou1' => 'http://jx.jfysz.cn/jx.php/?url=',
  'jiekou2' => 'http://jiexi.92fz.cn/player/vip.php?url=',
  'jiekou3' => 'http://www.ibb6.com/jx/yun.php?url=',
  'jiekou4' => 'http://www.ibb6.com/jiexi/?url=',
  'jiekou5' => 'http://www.ibb6.com/playm3u8/?url=',
  'jiekouyk' => 'http://www.ibb6.com/jiexi/?url=',
  'jiekouyy' => 'http://api.baiyug.cn/vip/index.php?url=',
  'admin_name' => 'admin',
  'admin_pass' => '3ceb0e9fb16f8673c35f707e8657124a',
  'admin_email' => 'admin@domain.com',
  'logo_dh' => '<img src="images/logo.png">',
  'logo_ss' => '<img id="imgsrc" src="images/sologo.png">',
  'movie_ad' => '<a href="http://vip.5aiym.top/dataoke/" target="_blank"><img src="images/ggzm.png" style="width:100%"></a>',
  'tv_ad' => '<a href="http://vip.5aiym.top/dataoke/" target="_blank"><img src="images/ggzm.png" style="width:100%"></a>',
  'zongyi_ad' => '<a href="http://vip.5aiym.top/dataoke/" target="_blank"><img src="images/ggzm.png" style="width:100%"></a>',
  'dongman_ad' => '<a href="http://vip.5aiym.top/dataoke/" target="_blank"><img src="images/ggzm.png" style="width:100%"></a>',
  'bofang_ad' => '<a href="http://vip.5aiym.top/dataoke/" target="_blank"><img src="images/ggzm.png" style="width:100%"></a>',
  'jiazai_ad' => '<a href="http://vip.5aiym.top/dataoke/" target="_blank"><img src="images/jiazai.png" width="100%"></a>',
  'tishi_ad' => '<style> 
 .black_overlay{  display: none;  position: absolute;  top: 0%;  left: 0%;  width: 100%;  height: 100%;  background-color: black;  z-index:1001;  -moz-opacity: 0.8;  opacity:.80;  filter: alpha(opacity=80);  }  .white_content {  display: none;  position: absolute;  top: 25%;  left: 25%;  width: 50%;   height: auto; padding: 16px;  border: 16px solid orange;  background-color: white;  z-index:1002;  overflow: auto;  }  </style> 
<a href="javascript:void(0)" onclick="document.getElementById(\'light\').style.display=\'block\';document.getElementById(\'fade\').style.display=\'block\'"><p style="text-align:center;color: #fff;font-size: 10px;background: #6ED56C;padding:11px 8px;border-radius: 2px;">点击添加“羊毛小生活”官方微信，看电影薅羊毛更方便!</p></a>
<div id="light" class="white_content"> 
  <img src="images/qrcode.png" width="100%" height="100%">
    <a href="javascript:void(0)" onclick="document.getElementById(\'light\').style.display=\'none\';document.getElementById(\'fade\').style.display=\'none\'"> 
    <span class="rewards-popover-close" etap="rewards-close"></span></a></div> 
<div id="fade" class="black_overlay"> 
</div> ',
  'dbts' => '【亲，点击选择播放源或者剧集再点击线路才会播放视频哦！】',
  'zfb_ad' => '<img src="images/zfb.png">',
  'wx_ad' => '<img src="images/wx.png">',
  'cebian1_ad' => '<a class="style01" href="https://ym.5aiym.top/63.html" target="_blank"><strong>关注微信公众号</strong><div class="article-wechats"> </br> <img src="images/qrcode.jpg"></div></a>',
  'cebian2_ad' => '<a class="style02" href="https://ym.5aiym.top/319.html" target="_blank"><strong>每天支付宝扫码领红包</strong><div class="article-wechats"> </br> <img src="images/hongbao.jpg"></div></a>',
  'cebian3_ad' => '<a class="style01" href="https://item.taobao.com/item.htm?id=573038448404" target="_blank"><strong>完整网站源码出售</strong><h2>简洁流畅的视频主题</h2><p>1.扁平化、简洁风、多功能配置，优秀的电脑、平板、手机支持，响应式布局，不同设备不同展示效果...</br>2.视频全自动采集，不需人工干预，懒人必备！</p></a>',
  'cebian4_ad' => '',
  'top1_ad' => '',
  'top2_ad' => '',
  'top_ad' => '<a href="https://ym.5aiym.top/" style="color:red;">薅羊毛抢红包</a>',
  'weixin_ad' => '<img src="images/qrcode.jpg">',
  'end_ad' => '<a href="https://ym.5aiym.top/"><span><img src="images/gouwu.png"/>薅羊毛抢红包</span></a>',
  'dtk_ad' => 'http://vip.5aiym.top/dataoke',
  'dtk_id' => '1161078',
  'qq_name' => '醉玲珑#无证之罪#权力的游戏第七季',
  'hometopnotice' => '',
  'hometopright' => '',
  'sort' => '1,2,3,4,5,6,7,8,9,10',
  'joinhotkey' => '0',
);
?>